extends Camera3D

@onready var camera:Camera3D = $"../../../Camera3D"


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	self.global_transform = camera.global_transform
