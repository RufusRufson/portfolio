extends CharacterBody3D

@export var speed = 10
@export var jump_velocity = 4.5

@export var headbob_speed = 10.0
@export var headbob_amount_vertical = 0.05
@export var headbob_amount_horizontal = 0.05
@export var headbob_lerp = 10.0

@export var landing_dip_strength = 0.12
@export var landing_dip_lerp = 8.0

var look_sensitivity = ProjectSettings.get_setting("player/look_sensitivity")
var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")

var velocity_y = 0
var headbob_time = 0.0
var camera_origin: Vector3
var previous_bob_value = 0.0

var was_on_floor = false
var landing_dip = 0.0

# 🔽 NOWE — input z pada
var look_input := Vector2.ZERO
var controller_sensitivity := 350.0

@onready var camera: Camera3D = $Camera3D
@onready var audio_stream_player_3d: AudioStreamPlayer3D = $AudioStreamPlayer3D


func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	camera_origin = camera.position


func _physics_process(delta):

	# 🎮 INPUT Z D-PADA
	look_input.x = Input.get_action_strength("turn_right") - Input.get_action_strength("turn_left")
	look_input.y = Input.get_action_strength("look_down") - Input.get_action_strength("look_up")

	# 🎮 OBRÓT Z PADA
	if look_input.length() > 0.01:
		rotate_y(-look_input.x * look_sensitivity * controller_sensitivity * delta)
		camera.rotate_x(-look_input.y * look_sensitivity * controller_sensitivity * delta)
		camera.rotation.x = clamp(camera.rotation.x, -PI/2, PI/2)

	var horizontal_velocity = Input.get_vector("move_left","move_right","move_forward","move_backward").normalized() * speed
	velocity = horizontal_velocity.x * global_transform.basis.x + horizontal_velocity.y * global_transform.basis.z
	
	if is_on_floor():
		velocity_y = jump_velocity if Input.is_action_just_pressed("jump") else 0
	else:
		velocity_y -= gravity * delta

	velocity.y = velocity_y
	move_and_slide()

	# wykrycie lądowania
	if not was_on_floor and is_on_floor() and velocity_y < -3.0:
		audio_stream_player_3d.pitch_scale = randf_range(0.5, 0.7)
		audio_stream_player_3d.play()
		landing_dip = landing_dip_strength

	was_on_floor = is_on_floor()

	update_headbob(delta)

	# ESC toggle
	if Input.is_action_just_pressed("ui_cancel"):
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)


func update_headbob(delta):

	var target_position = camera_origin
	var horizontal_speed = Vector3(velocity.x, 0, velocity.z).length()

	if is_on_floor() and horizontal_speed > 0.1:

		headbob_time += delta * headbob_speed

		var bob = sin(headbob_time)

		var vertical = bob * headbob_amount_vertical
		var horizontal = cos(headbob_time) * headbob_amount_horizontal

		var right = camera.transform.basis.x

		target_position += Vector3(0, vertical, 0) + right * horizontal

		# krok gdy sin przechodzi przez minimum
		if previous_bob_value > -0.95 and bob <= -0.95:
			audio_stream_player_3d.pitch_scale = randf_range(0.8, 1.1)
			audio_stream_player_3d.play()

		previous_bob_value = bob

	else:
		headbob_time = 0
		previous_bob_value = 0

	# landing dip
	target_position.y -= landing_dip
	landing_dip = lerp(landing_dip, 0.0, delta * landing_dip_lerp)

	camera.position = camera.position.lerp(target_position, delta * headbob_lerp)


func _input(event):
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * look_sensitivity)
		camera.rotate_x(-event.relative.y * look_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x, -PI/2, PI/2)

	# kliknięcie przywraca fullscreen i blokuje kursor
	if event is InputEventMouseButton and event.pressed:
		if Input.mouse_mode == Input.MOUSE_MODE_VISIBLE:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
