extends Area3D

@export var target_scene: String = ""
@export var possible_scenes: Array[String] = []

func _ready():
	body_entered.connect(_on_body_entered)

func _on_body_entered(body):
	if not body is CharacterBody3D:
		return

	var scene_to_load = target_scene

	# jeśli nie ustawiono konkretnej sceny → losuj
	if scene_to_load == "" and possible_scenes.size() > 0:
		scene_to_load = possible_scenes.pick_random()

	if scene_to_load != "":
		get_tree().change_scene_to_file(scene_to_load)
